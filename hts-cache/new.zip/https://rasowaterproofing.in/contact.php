<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Raaso Waterproofing</title>
    <!-- Favicons Icons -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/raaso-logo.jpg" />
    <meta name="description" content="Raso Waterproofing " />

    <!-- Fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&amp;display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Yantramanav:wght@100;300;400;500;700;900&amp;display=swap"
        rel="stylesheet">



    <link rel="stylesheet" href="assets/vendors/animate/animate.min.css" />
    <link rel="stylesheet" href="assets/vendors/animate/custom-animate.css" />
    <link rel="stylesheet" href="assets/vendors/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/vendors/bxslider/jquery.bxslider.css" />
    <link rel="stylesheet" href="assets/vendors/fontawesome/css/all.min.css" />
    <link rel="stylesheet" href="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css" />
    <link rel="stylesheet" href="assets/vendors/jquery-ui/jquery-ui.css" />
    <link rel="stylesheet" href="assets/vendors/nice-select/nice-select.css" />
    <link rel="stylesheet" href="assets/vendors/odometer/odometer.min.css" />
    <link rel="stylesheet" href="assets/vendors/owl-carousel/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/vendors/owl-carousel/owl.theme.default.min.css" />
    <link rel="stylesheet" href="assets/vendors/swiper/swiper.min.css" />
    <link rel="stylesheet" href="assets/vendors/vegas/vegas.min.css" />
    <link rel="stylesheet" href="assets/vendors/thm-icons/style.css">
    <link rel="stylesheet" href="assets/vendors/language-switcher/polyglot-language-switcher.css">
    <link rel="stylesheet" href="assets/vendors/fancybox/fancybox.min.css">
    <link rel="stylesheet" href="assets/vendors/aos/aos.css">

    <!-- Module css -->
    <link rel="stylesheet" href="assets/css/module-css/01-header-section.css">
    <link rel="stylesheet" href="assets/css/module-css/02-banner-section.css">
    <link rel="stylesheet" href="assets/css/module-css/03-about-section.css">
    <link rel="stylesheet" href="assets/css/module-css/04-fact-counter-section.css">
    <link rel="stylesheet" href="assets/css/module-css/05-testimonial-section.css">
    <link rel="stylesheet" href="assets/css/module-css/06-partner-section.css">
    <link rel="stylesheet" href="assets/css/module-css/07-footer-section.css">
    <link rel="stylesheet" href="assets/css/module-css/08-blog-section.css">
    <link rel="stylesheet" href="assets/css/module-css/09-breadcrumb-section.css">
    <link rel="stylesheet" href="assets/css/module-css/10-contact.css">
    

    <!-- Template styles -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  
</head>


<body>


    <!-- preloader -->
    <div class="loader-wrap">
        <div class="preloader">
            <div id="handle-preloader" class="handle-preloader">
                <div class="layer layer-one"><span class="overlay"></span></div>
                <div class="layer layer-two"><span class="overlay"></span></div>
                <div class="layer layer-three"><span class="overlay"></span></div>
                <div class="animation-preloader text-center">
                    <div class="spinner"></div>
                    <!-- <img src="assets/images/raaso-logo.jpg" style="height:100px;" alt=""> -->
                    <div class="txt-loading">
                        <span data-text-preloader="R" class="letters-loading">
                            R
                        </span>
                        <span data-text-preloader="A" class="letters-loading">
                            A
                        </span>                        
                        <span data-text-preloader="S" class="letters-loading">
                            S
                        </span>
                        <span data-text-preloader="O" class="letters-loading">
                            O
                        </span>
                        <span >&nbsp;&nbsp;</span>
                        <span data-text-preloader="W" class="letters-loading">
                            W
                        </span>
                        <span data-text-preloader="A" class="letters-loading">
                            A
                        </span>
                        <span data-text-preloader="T" class="letters-loading">
                            T
                        </span>
                        <span data-text-preloader="E" class="letters-loading">
                           E
                        </span>
                        <span data-text-preloader="R" class="letters-loading">
                            R
                        </span>
                        <span ><br></span>
                        <span data-text-preloader="P" class="letters-loading">
                            P
                        </span>
                        <span data-text-preloader="R" class="letters-loading">
                            R
                        </span>
                        <span data-text-preloader="O" class="letters-loading">
                            O
                        </span>
                        <span data-text-preloader="O" class="letters-loading">
                           O
                        </span>
                        <span data-text-preloader="F" class="letters-loading">
                            F
                        </span>
                        <span data-text-preloader="I" class="letters-loading">
                            I
                        </span>
                        <span data-text-preloader="N" class="letters-loading">
                            N
                        </span>
                        <span data-text-preloader="G" class="letters-loading">
                            G
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- preloader end -->


    <!-- Start sidebar widget content -->
    <div class="xs-sidebar-group info-group info-sidebar">
        <div class="xs-overlay xs-bg-black"></div>
        <div class="xs-sidebar-widget">
            <div class="sidebar-widget-container">
                <div class="widget-heading">
                    <a href="#" class="close-side-widget">X</a>
                </div>
                <div class="sidebar-textwidget">
                    <div class="sidebar-info-contents">
                        <div class="content-inner">
                            <div class="logo text-center">
                                <a href="index.php"><img src="assets/images/raaso-logo.jpg" alt="" /></a>
                            </div>
                            <div class="content-box">
                                <h3>We Provide Roof Repairing<br> And Renovation</h3>
                                <div class="inner-text">
                                    <p>
                                        Our experienced team offers services for both residential and commercial
                                        properties.With over 25 years of experience in the industry, we boast all of the
                                        knowledge and expertise in repairing.
                                    </p>
                                </div>
                            </div>

                            <div class="sidebar-contact-info">
                                <h3>Conatct Us</h3>
                                <ul>
                                    <li>
                                        <div class="inner">
                                            <div class="icon">
                                                <img src="assets/images/icon/icon-7__mapmarker.png" alt="">
                                            </div>
                                            <div class="text">
                                                <p>I-86, near kavita palace, Azad Vihar, Khora Colony, Sector 62A, <br> Noida, Uttar Pradesh 201309</p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="inner">
                                            <div class="icon">
                                                <img src="assets/images/icon/icon-8__envelop.png" alt="">
                                            </div>
                                            <div class="text">
                                                <p><a href="mailto:contact@rasowaterproofing.com">contact@rasowaterproofing.com</a></p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="inner">
                                            <div class="icon">
                                                <img src="assets/images/icon/icon-9__phone.png" alt="">
                                            </div>
                                            <div class="text">
                                                <p><a href="tel:+918851311255">+91 88513 11255</a></p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="inner">
                                            <div class="icon">
                                                <img src="assets/images/icon/icon-10__clock.png" alt="">
                                            </div>
                                            <div class="text">
                                                <p>Working Hrs : 9.30am to 6.30pm</p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                            <div class="thm-social-link">
                                <ul class="clearfix">
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-youtube"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-facebook-f"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End sidebar widget content -->






    <div class="page-wrapper boxed_wrapper">
        <header class="main-header main-header-style1">

            <!--Start Main Header Style1 Top-->
            <div class="main-header-style1__top">
                <div class="container">
                    <div class="outer-box">
                        <!--Start Main Header Style1 Top Left-->
                        <div class="main-header-style1__top-left">
                            <h3># 1 Water Proofing & Renovation Company of Delhi NCR.
                                <a href="contact.php">Get Appointment Today</a></h3>
                        </div>
                        <!--End Main Header Style1 Top Left-->

                        <!--Start Main Header Style1 Top Right-->
                        <div class="main-header-style1__top-right">
                            <div class="phone-number-box-style1">
                                <span class="icon-phone"></span>
                                <a href="tel:+91 88513 11255">+91 88513 11255</a>
                            </div>
                        </div>
                        <!--End Main Header Style1 Top Right-->

                    </div>
                </div>
            </div>
            <!--End Main Header Style1 Top-->

            <nav class="main-menu main-menu-style1">
                <div class="main-menu__wrapper clearfix">
                    <div class="container">
                        <div class="main-menu__wrapper-inner">

                            <div class="main-menu-style1-left">
                                <div class="logo-box-style1">
                                    <a href="index.php">
                                        <img src="assets/images/raaso-logo.jpg" alt="Awesome Logo" title="">
                                    </a>
                                </div>
                            </div>

                            <div class="main-menu-style1-right">
                                <div class="main-menu-box">
                                    <a href="#" class="mobile-nav__toggler">
                                        <i class="icon-bars"></i>
                                    </a>
                                    <ul class="main-menu__list">
                                        <li class="current">
                                            <a href="index.php">Home</a>
                                        </li>
                                        <li>
                                            <a href="index.php#about">About Us</a>
                                        </li>
                                        <li>
                                            <a href="index.php#services">Our Services</a>
                                        </li>
                                        <!-- <li class="dropdown">
                                            <a href="#">Blog</a>
                                            <ul>
                                                <li><a href="blog.html">Blog Classic</a></li>
                                                <li><a href="blog-2.html">Blog Grid View</a></li>
                                                <li><a href="blog-single.html">Single Post</a></li>
                                            </ul>
                                        </li> -->
                                        <li>
                                            <a href="contact.php">Contact Us</a>
                                        </li>
                                    </ul>
                                </div>

                                <div class="box-search-style1">
                                    <!-- <a href="#" class="search-toggler">
                                        <img src="assets/images/icon/icon-2__searchbar.png" alt="">
                                    </a> -->
                                </div>
                                <div class="side-content-button">
                                    <a class="navSidebar-button" href="#">
                                        <img src="assets/images/icon/icon-1__menubar.png" alt="">
                                    </a>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </nav>


        </header>


        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->
<!--Start breadcrumb area-->
<section class="breadcrumb-area">
    <div class="breadcrumb-area-bg paroller"
        style="background-image: url(assets/images/breadcrumb/breadcrumb-1.jpg);">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="inner-content">
                    <div class="title">
                        <h2>Contact Us</h2>
                    </div>
                    <div class="breadcrumb-menu">
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            <li class="active">Contact Us</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb area-->

<!--Start Main Contact Form Area-->
<section class="main-contact-form-area">
    <div class="container">
        <div class="row">

            <div class="col-xl-8">
                <div class="contact-form">
                    <div class="sec-title">
                        <div class="sub-title">
                            <div class="border-left"></div>
                            <h5>get in touch</h5>
                        </div>
                        <h2>Drop a Message</h2>
                    </div>
                    <form id="enquiry_form" name="contact_form" class="default-form2"
                        action="mail.php" method="post">
                        <div class="row">
                            <div class="col-xl-6">
                                <div class="form-group">
                                    <div class="input-box">
                                        <input type="text" name="form_name" id="formName"
                                            placeholder="Your Name" required="">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="form-group">
                                    <div class="input-box">
                                        <input type="email" name="form_email" id="formEmail"
                                            placeholder="Your Email" required="">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-6">
                                <div class="form-group">
                                    <div class="input-box">
                                        <input type="text" name="form_phone" value="" id="formPhone"
                                            placeholder="Phone">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="form-group">
                                    <div class="input-box">
                                        <input type="text" name="form_subject" value="" id="formSubject"
                                            placeholder="Subject">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-12">
                                <div class="form-group">
                                    <div class="input-box">
                                        <textarea name="address" id="formMessage" placeholder="Address"
                                            required=""></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-12">
                                <div class="button-box">
                                    <input id="form_botcheck" name="form_botcheck" class="form-control"
                                        type="hidden" value="">
                                    <button class="btn-one" type="submit" name="sub"data-loading-text="Please wait...">
                                        <span class="txt">
                                            submit now <i class="icon-right"></i>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>

            <div class="col-xl-4">
                <div class="contact-info-box-style1">
                    <div class="title">
                        <h2>Our Address</h2>
                        <p>Completely synergize resource taxing relationships niche markets.
                            Professionally cultivate one-to-one customer service.</p>
                    </div>
                    <ul class="contact-info-1">
                        <li>
                            <div class="icon">
                                <span class="icon-location"></span>
                            </div>
                            <div class="text">
                                <h3>Address:</h3>
                                <p>I-86, near kavita palace, Azad Vihar, Khora Colony, Sector 62A, Noida, Uttar Pradesh 201309</p>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-telephone"></span>
                            </div>
                            <div class="text">
                                <h3>Phone :</h3>
                                <p>
                                    <a href="tel:+91 88513 11255">+91 88513 11255</a>
                                </p>
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <span class="icon-envelope"></span>
                            </div>
                            <div class="text">
                                <h3>Email :</h3>
                                <p><a href="mailto:Rasowaterproofing@gmail.com">Rasowaterproofing@gmail.com</a></p>
                            </div>
                        </li>
                    </ul>

                </div>
            </div>

        </div>
    </div>


    <div class="container">
        <div class="google-map-outer-box">
            <!--Google Map Start-->
            <div class="google-map">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3502.481342678446!2d77.34807651455924!3d28.615332491611!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cef2733d7b965%3A0x68075c34f9b830!2sRASO%20WATERPROOFING%20COMPANY!5e0!3m2!1sen!2sin!4v1677345702578!5m2!1sen!2sin" class="google-map__one" allowfullscreen></iframe>
            </div>
            <!--Google Map End-->
        </div>
    </div>

</section>
<!--End Main Contact Form Area-->


<!--Start footer area -->
<footer class="footer-area">
    <div class="footer-area-img-box" data-aos="slide-up" data-aos-easing="linear" data-aos-duration="2500">
        <img class="float-bob-y" src="assets/images/footer/footer-area-img-1.png" alt="">
    </div>
    <!--Start Footer Top-->
    <div class="footer-top">
        <div class="container">
            <div class="footer-top__inner">
                <ul class="footer-contact-info-box1">
                    <li>
                        <div class="footer-contact-info-box1__single">
                            <div class="icon">
                                <span class="icon-location"></span>
                            </div>
                            <div class="text">
                                <p> I-86, near kavita palace, Azad Vihar, Khora Colony, Sector 62A, <br> Noida, Uttar Pradesh 201309</p>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="footer-contact-info-box1__single">
                            <div class="icon">
                                <span class="icon-envelope"></span>
                            </div>
                            <div class="text">
                                <p>Email us:</p>
                                <h5><a href="mailto:Rasowaterproofing@gmail.com">Rasowaterproofing@gmail.com</a></h5>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="footer-contact-info-box1__single">
                            <div class="icon">
                                <span class="icon-telephone"></span>
                            </div>
                            <div class="text">
                                <p>Call us on:</p>
                                <h5><a href="tel:+918851311255">+91 88513 11255</a></h5>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!--End Footer Top-->

    <!--Start Footer Top-->
    <div class="footer-main">
        <div class="container">
            <div class="row">
                <!--Start single footer widget-->
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 single-widget">
                    <div class="single-footer-widget">
                        <div class="our-company-info">
                            <div class="footer-logo-style1">
                                <a href="index.php">
                                    <img src="assets/images/raaso-logo.jpg" alt="Awesome Logo"
                                        title="">
                                </a>
                            </div>
                            <div class="text">
                                <p>Raso Waterproofing Company is a Delhi NCR based company undertaking waterproofing works all over India, we are known for executing challenging jobs with even tight Schedules. </p>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End single footer widget-->

                <!--Start single footer widget-->
                <div class="col-xl-2 col-lg-6 col-md-6 col-sm-12 single-widget">
                    <div class="single-footer-widget single-footer-widget--link-box margin-leftminus1">
                        <div class="title">
                            <h3>Useful Links</h3>
                        </div>
                        <div class="footer-widget-links">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="#">About Us</a></li>
                                <li><a href="contact.php">Appointment</a></li>
                                <li><a href="#">Testimonials</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--End single footer widget-->

                <!--Start single footer widget-->
                <div class="col-xl-2 col-lg-6 col-md-6 col-sm-12 single-widget">
                    <div class="single-footer-widget single-footer-widget--link-box margin-leftminus2">
                        <div class="title">
                            <h3>Our Services</h3>
                        </div>
                        <div class="footer-widget-links">
                            <ul>
                                <li><a href="#">Roof Repairing</a></li>
                                <li><a href="#">Roof Installation</a></li>
                                <li><a href="#">Siding Corner</a></li>
                                <li><a href="#">Damage Roof Repairs</a></li>
                                <li><a href="#">Roof Layers</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--End single footer widget-->

                <!--Start single footer widget-->
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 single-widget">
                    <div class="single-footer-widget">
                        <div class="title">
                            <h3>Newsletter</h3>
                        </div>
                        <div class="footer-widget-newsletter-box">
                            <p>Get latest updates and offers.</p>
                            <form action="#" method="post">
                                <div class="form-group">
                                    <input type="email" name="email" placeholder="Enter your email address"
                                        required="">
                                    <button class="submit">
                                        <i class="icon-send"></i>
                                    </button>
                                </div>
                            </form>

                            <div class="footer-social-link">
                                <ul class="clearfix">
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-youtube"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/rasowaterproofing/?igshid=YmMyMTA2M2Y%3D">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.facebook.com/people/RASO-Waterproofing/100075980678693/?mibextid=ZbWKwL">
                                            <i class="fab fa-facebook-f"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
                <!--End single footer widget-->

            </div>
        </div>
    </div>
    <!--End Footer Top-->

    <div class="footer-bottom">
        <div class="container">
            <div class="bottom-inner">
                <div class="copyright-text">
                    <p>
                        &copy; Copyright <a href="index.html">Raso Water Proofing</a> 2022. All right reserved.<br>
                    </p>
                </div>
                <div class="footer-bottom-right">
                    <!-- <p>Created by <a href="#">DesignArc</a></p> -->
                </div>
            </div>
        </div>
    </div>

</footer>
<!--End footer area-->



</div>
<!-- /.page-wrapper -->


<div class="mobile-nav__wrapper">
<div class="mobile-nav__overlay mobile-nav__toggler"></div>
<div class="mobile-nav__content">
    <span class="mobile-nav__close mobile-nav__toggler">
        <i class="icon-x"></i>
    </span>
    <div class="logo-box">
        <a href="index.html" aria-label="logo image">
            <img src="assets/images/resources/mobile-nav-logo.png" alt="" />
        </a>
    </div>
    <div class="mobile-nav-search-box">
        <form class="search-form" action="#">
            <input placeholder="Keyword" type="text">
            <button type="submit">
                <i class="icon-search-interface-symbol"></i>
            </button>
        </form>
    </div>
    <div class="mobile-nav__container"></div>
    <ul class="mobile-nav__contact list-unstyled">
        <li>
            <i class="fa fa-envelope"></i>
            <a href="mailto:info@example.com">info@example.com</a>
        </li>
        <li>
            <i class="fa fa-phone-alt"></i>
            <a href="tel:123456789">444 000 777 66</a>
        </li>
    </ul>
    <div class="mobile-nav__social">
        <a href="#" class="fab fa-twitter"></a>
        <a href="#" class="fab fa-facebook-square"></a>
        <a href="#" class="fab fa-pinterest-p"></a>
        <a href="#" class="fab fa-instagram"></a>
    </div>
</div>
</div>


<div class="search-popup">
    <div class="search-popup__overlay search-toggler"></div>
        <div class="search-popup__content">
            <form action="#">
                <label for="search" class="sr-only">search here</label>
                <input type="text" id="search" placeholder="Search Here..." />
                <button type="submit" aria-label="search submit" class="thm-btn">
                    <i class="icon-search-interface-symbol"></i>
                </button>
            </form>
        </div>
    </div>



<!--Scroll to top-->
<div class="scroll-to-top">
<div>
    <div class="scroll-top-inner">
        <div class="scroll-bar">
            <div class="bar-inner"></div>
        </div>
        <div class="scroll-bar-text">Go To Top</div>
    </div>
</div>
</div>
<!-- Scroll to top end -->


<script src="assets/vendors/jquery/jquery-3.6.0.min.js"></script>
<script src="assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendors/bxslider/jquery.bxslider.min.js"></script>
<script src="assets/vendors/circleType/jquery.circleType.js"></script>
<script src="assets/vendors/circleType/jquery.lettering.min.js"></script>
<script src="assets/vendors/isotope/isotope.js"></script>
<script src="assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js"></script>
<script src="assets/vendors/jquery-appear/jquery.appear.min.js"></script>
<script src="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="assets/vendors/jquery-migrate/jquery-migrate.min.js"></script>
<script src="assets/vendors/jquery-ui/jquery-ui.js"></script>
<script src="assets/vendors/jquery-validate/jquery.validate.min.js"></script>
<script src="assets/vendors/nice-select/jquery.nice-select.min.js"></script>
<script src="assets/vendors/odometer/odometer.min.js"></script>
<script src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="assets/vendors/swiper/swiper.min.js"></script>
<script src="assets/vendors/vegas/vegas.min.js"></script>
<script src="assets/vendors/wnumb/wNumb.min.js"></script>
<script src="assets/vendors/wow/wow.js"></script>
<script src="assets/vendors/extra-scripts/jquery.paroller.min.js"></script>
<script src="assets/vendors/language-switcher/jquery.polyglot.language.switcher.js"></script>
<script src="assets/vendors/extra-scripts/jquery-sidebar-content.js"></script>
<script src="assets/vendors/fancybox/jquery.fancybox.js"></script>
<script src="assets/vendors/aos/aos.js"></script>
<script src="assets/vendors/extra-scripts/jarallax.min.js"></script>
<script src="assets/vendors/extra-scripts/TweenMax.min.js"></script>


<!-- Template js -->
<script src="assets/js/custom.js"></script>
<script>
   $("form#enquiry_form").submit(function(e) {
      $(':button[type="submit"]').prop('disabled', true);
    e.preventDefault();    
    var formData = new FormData(this);
    $.ajax({
    url: $(this).attr('action'),
    type: 'POST',
    data: formData,
    cache: false,
    contentType: false,
    processData: false,
    dataType: 'json',
    success: function (data) {
        if(data.status==200) {
        //$('.modal').modal('hide');
        toastr.success(data.message);
        setTimeout(function(){
        location.reload();
        },1000)
        }else if(data.status==403) {
        toastr.error(data.message);
        $(':input[type="submit"]').prop('disabled', false);
        }else{
        toastr.error('Something went wrong');
        $(':input[type="submit"]').prop('disabled', false);
        }
    },
    error: function(){} 
    });
});
</script>

</body>
</html>