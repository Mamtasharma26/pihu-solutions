<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Raaso Waterproofing</title>
    <!-- Favicons Icons -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/raaso-logo.jpg" />
    <meta name="description" content="Raso Waterproofing " />

    <!-- Fonts -->
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&amp;display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Yantramanav:wght@100;300;400;500;700;900&amp;display=swap"
        rel="stylesheet">



    <link rel="stylesheet" href="assets/vendors/animate/animate.min.css" />
    <link rel="stylesheet" href="assets/vendors/animate/custom-animate.css" />
    <link rel="stylesheet" href="assets/vendors/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/vendors/bxslider/jquery.bxslider.css" />
    <link rel="stylesheet" href="assets/vendors/fontawesome/css/all.min.css" />
    <link rel="stylesheet" href="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css" />
    <link rel="stylesheet" href="assets/vendors/jquery-ui/jquery-ui.css" />
    <link rel="stylesheet" href="assets/vendors/nice-select/nice-select.css" />
    <link rel="stylesheet" href="assets/vendors/odometer/odometer.min.css" />
    <link rel="stylesheet" href="assets/vendors/owl-carousel/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/vendors/owl-carousel/owl.theme.default.min.css" />
    <link rel="stylesheet" href="assets/vendors/swiper/swiper.min.css" />
    <link rel="stylesheet" href="assets/vendors/vegas/vegas.min.css" />
    <link rel="stylesheet" href="assets/vendors/thm-icons/style.css">
    <link rel="stylesheet" href="assets/vendors/language-switcher/polyglot-language-switcher.css">
    <link rel="stylesheet" href="assets/vendors/fancybox/fancybox.min.css">
    <link rel="stylesheet" href="assets/vendors/aos/aos.css">

    <!-- Module css -->
    <link rel="stylesheet" href="assets/css/module-css/01-header-section.css">
    <link rel="stylesheet" href="assets/css/module-css/02-banner-section.css">
    <link rel="stylesheet" href="assets/css/module-css/03-about-section.css">
    <link rel="stylesheet" href="assets/css/module-css/04-fact-counter-section.css">
    <link rel="stylesheet" href="assets/css/module-css/05-testimonial-section.css">
    <link rel="stylesheet" href="assets/css/module-css/06-partner-section.css">
    <link rel="stylesheet" href="assets/css/module-css/07-footer-section.css">
    <link rel="stylesheet" href="assets/css/module-css/08-blog-section.css">
    <link rel="stylesheet" href="assets/css/module-css/09-breadcrumb-section.css">
    <link rel="stylesheet" href="assets/css/module-css/10-contact.css">
    

    <!-- Template styles -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  
</head>


<body>


    <!-- preloader -->
    <div class="loader-wrap">
        <div class="preloader">
            <div id="handle-preloader" class="handle-preloader">
                <div class="layer layer-one"><span class="overlay"></span></div>
                <div class="layer layer-two"><span class="overlay"></span></div>
                <div class="layer layer-three"><span class="overlay"></span></div>
                <div class="animation-preloader text-center">
                    <div class="spinner"></div>
                    <!-- <img src="assets/images/raaso-logo.jpg" style="height:100px;" alt=""> -->
                    <div class="txt-loading">
                        <span data-text-preloader="R" class="letters-loading">
                            R
                        </span>
                        <span data-text-preloader="A" class="letters-loading">
                            A
                        </span>                        
                        <span data-text-preloader="S" class="letters-loading">
                            S
                        </span>
                        <span data-text-preloader="O" class="letters-loading">
                            O
                        </span>
                        <span >&nbsp;&nbsp;</span>
                        <span data-text-preloader="W" class="letters-loading">
                            W
                        </span>
                        <span data-text-preloader="A" class="letters-loading">
                            A
                        </span>
                        <span data-text-preloader="T" class="letters-loading">
                            T
                        </span>
                        <span data-text-preloader="E" class="letters-loading">
                           E
                        </span>
                        <span data-text-preloader="R" class="letters-loading">
                            R
                        </span>
                        <span ><br></span>
                        <span data-text-preloader="P" class="letters-loading">
                            P
                        </span>
                        <span data-text-preloader="R" class="letters-loading">
                            R
                        </span>
                        <span data-text-preloader="O" class="letters-loading">
                            O
                        </span>
                        <span data-text-preloader="O" class="letters-loading">
                           O
                        </span>
                        <span data-text-preloader="F" class="letters-loading">
                            F
                        </span>
                        <span data-text-preloader="I" class="letters-loading">
                            I
                        </span>
                        <span data-text-preloader="N" class="letters-loading">
                            N
                        </span>
                        <span data-text-preloader="G" class="letters-loading">
                            G
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- preloader end -->


    <!-- Start sidebar widget content -->
    <div class="xs-sidebar-group info-group info-sidebar">
        <div class="xs-overlay xs-bg-black"></div>
        <div class="xs-sidebar-widget">
            <div class="sidebar-widget-container">
                <div class="widget-heading">
                    <a href="#" class="close-side-widget">X</a>
                </div>
                <div class="sidebar-textwidget">
                    <div class="sidebar-info-contents">
                        <div class="content-inner">
                            <div class="logo text-center">
                                <a href="index.php"><img src="assets/images/raaso-logo.jpg" alt="" /></a>
                            </div>
                            <div class="content-box">
                                <h3>We Provide Roof Repairing<br> And Renovation</h3>
                                <div class="inner-text">
                                    <p>
                                        Our experienced team offers services for both residential and commercial
                                        properties.With over 25 years of experience in the industry, we boast all of the
                                        knowledge and expertise in repairing.
                                    </p>
                                </div>
                            </div>

                            <div class="sidebar-contact-info">
                                <h3>Conatct Us</h3>
                                <ul>
                                    <li>
                                        <div class="inner">
                                            <div class="icon">
                                                <img src="assets/images/icon/icon-7__mapmarker.png" alt="">
                                            </div>
                                            <div class="text">
                                                <p>I-86, near kavita palace, Azad Vihar, Khora Colony, Sector 62A, <br> Noida, Uttar Pradesh 201309</p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="inner">
                                            <div class="icon">
                                                <img src="assets/images/icon/icon-8__envelop.png" alt="">
                                            </div>
                                            <div class="text">
                                                <p><a href="mailto:contact@rasowaterproofing.com">contact@rasowaterproofing.com</a></p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="inner">
                                            <div class="icon">
                                                <img src="assets/images/icon/icon-9__phone.png" alt="">
                                            </div>
                                            <div class="text">
                                                <p><a href="tel:+918851311255">+91 88513 11255</a></p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="inner">
                                            <div class="icon">
                                                <img src="assets/images/icon/icon-10__clock.png" alt="">
                                            </div>
                                            <div class="text">
                                                <p>Working Hrs : 9.30am to 6.30pm</p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                            <div class="thm-social-link">
                                <ul class="clearfix">
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-youtube"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-facebook-f"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End sidebar widget content -->






    <div class="page-wrapper boxed_wrapper">
        <header class="main-header main-header-style1">

            <!--Start Main Header Style1 Top-->
            <div class="main-header-style1__top">
                <div class="container">
                    <div class="outer-box">
                        <!--Start Main Header Style1 Top Left-->
                        <div class="main-header-style1__top-left">
                            <h3># 1 Water Proofing & Renovation Company of Delhi NCR.
                                <a href="contact.php">Get Appointment Today</a></h3>
                        </div>
                        <!--End Main Header Style1 Top Left-->

                        <!--Start Main Header Style1 Top Right-->
                        <div class="main-header-style1__top-right">
                            <div class="phone-number-box-style1">
                                <span class="icon-phone"></span>
                                <a href="tel:+91 88513 11255">+91 88513 11255</a>
                            </div>
                        </div>
                        <!--End Main Header Style1 Top Right-->

                    </div>
                </div>
            </div>
            <!--End Main Header Style1 Top-->

            <nav class="main-menu main-menu-style1">
                <div class="main-menu__wrapper clearfix">
                    <div class="container">
                        <div class="main-menu__wrapper-inner">

                            <div class="main-menu-style1-left">
                                <div class="logo-box-style1">
                                    <a href="index.php">
                                        <img src="assets/images/raaso-logo.jpg" alt="Awesome Logo" title="">
                                    </a>
                                </div>
                            </div>

                            <div class="main-menu-style1-right">
                                <div class="main-menu-box">
                                    <a href="#" class="mobile-nav__toggler">
                                        <i class="icon-bars"></i>
                                    </a>
                                    <ul class="main-menu__list">
                                        <li class="current">
                                            <a href="index.php">Home</a>
                                        </li>
                                        <li>
                                            <a href="index.php#about">About Us</a>
                                        </li>
                                        <li>
                                            <a href="index.php#services">Our Services</a>
                                        </li>
                                        <!-- <li class="dropdown">
                                            <a href="#">Blog</a>
                                            <ul>
                                                <li><a href="blog.html">Blog Classic</a></li>
                                                <li><a href="blog-2.html">Blog Grid View</a></li>
                                                <li><a href="blog-single.html">Single Post</a></li>
                                            </ul>
                                        </li> -->
                                        <li>
                                            <a href="contact.php">Contact Us</a>
                                        </li>
                                    </ul>
                                </div>

                                <div class="box-search-style1">
                                    <!-- <a href="#" class="search-toggler">
                                        <img src="assets/images/icon/icon-2__searchbar.png" alt="">
                                    </a> -->
                                </div>
                                <div class="side-content-button">
                                    <a class="navSidebar-button" href="#">
                                        <img src="assets/images/icon/icon-1__menubar.png" alt="">
                                    </a>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </nav>


        </header>


        <div class="stricky-header stricked-menu main-menu">
            <div class="sticky-header__content"></div><!-- /.sticky-header__content -->
        </div><!-- /.stricky-header -->
        <!--Main Slider Start-->
        <section class="main-slider main-slider-style1">
            <div class="swiper-container thm-swiper__slider" data-swiper-options='{"slidesPerView": 1, "loop": true,
                "effect": "fade",
                "pagination": {
                "el": "#main-slider-pagination",
                "type": "bullets",
                "clickable": true
                },
                "navigation": {
                "nextEl": "#main-slider__swiper-button-next",
                "prevEl": "#main-slider__swiper-button-prev"
                },
                "autoplay": {
                "delay": 8000
                }}'>
                <div class="swiper-wrapper">

                    <!--Start Single Swiper Slide-->
                    <div class="swiper-slide">
                        <img src="assets/images/slides/slide-v1-10.jpg" style="width:100%;height:400px">
                        <!-- <div class="image-layer" style="background-image: url(assets/images/slides/slide-v1-10.jpg);">
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="main-slider-content">
                                        <div class="main-slider-content__inner">
                                            <div class="big-title">
                                                <h2>Our Best Roof<br> Service Inspection</h2>
                                            </div>
                                            <div class="text">
                                                <p>
                                                    We believe in providing top quality workmanship and are<br> so
                                                    confident in our level of service that we back it up<br> with a good
                                                    quality.
                                                </p>
                                            </div>
                                            <div class="btn-box">
                                                <a class="btn-one" href="services.html">
                                                    <span class="txt">
                                                        view all services
                                                        <i class="icon-right"></i>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <!--End Single Swiper Slide-->

                    <!--Start Single Swiper Slide-->
                    <div class="swiper-slide">
                    <img src="assets/images/slides/slide-v1-2.jpg" style="width:100%;height:400px">
                        <!-- <div class="image-layer" style="background-image: url(assets/images/slides/slide-v1-2.jpg);">
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="main-slider-content">
                                        <div class="main-slider-content__inner">
                                            <div class="big-title">
                                                <h2>Quality Roof<br> Installation Service</h2>
                                            </div>
                                            <div class="text">
                                                <p>
                                                    We believe in providing top quality workmanship and are<br> so
                                                    confident in our level of service that we back it up<br> with a good
                                                    quality.
                                                </p>
                                            </div>
                                            <div class="btn-box">
                                                <a class="btn-one" href="services.html">
                                                    <span class="txt">
                                                        view all services
                                                        <i class="icon-right"></i>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <!--End Single Swiper Slide-->

                    <!--Start Single Swiper Slide-->
                    <div class="swiper-slide">
                        <img src="assets/images/slides/slide-v1-3.jpg" style="width:100%;height:400px">
                        <!-- <div class="image-layer" style="background-image: url(assets/images/slides/slide-v1-3.jpg);">
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="main-slider-content">
                                        <div class="main-slider-content__inner">
                                            <div class="big-title">
                                                <h2>We Build Roof<br> Expert Engineers</h2>
                                            </div>
                                            <div class="text">
                                                <p>
                                                    We believe in providing top quality workmanship and are<br> so
                                                    confident in our level of service that we back it up<br> with a good
                                                    quality.
                                                </p>
                                            </div>
                                            <div class="btn-box">
                                                <a class="btn-one" href="services.html">
                                                    <span class="txt">
                                                        view all services
                                                        <i class="icon-right"></i>
                                                    </span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <!--End Single Swiper Slide-->
                </div>

                <!-- If we need navigation buttons -->
                <div class="main-slider__nav">
                    <div class="swiper-button-prev" id="main-slider__swiper-button-next">
                        <i class="icon-left-arrow left"></i>
                    </div>
                    <div class="swiper-button-next" id="main-slider__swiper-button-prev">
                        <i class="icon-right-arrow right"></i>
                    </div>
                </div>

            </div>
        </section>
        <!--Main Slider End-->


        <!--Start About Style1 Area-->
        <section class="about-style1-area" id="about">
            <div class="container">
                <div class="row">
                    <div class="col-xl-4">
                        <div class="about-style1-img-box">
                            <ul>
                                <li>
                                    <div class="about-style1-img-box__single">
                                        <img src="assets/images/RASO/IMG-13.jpg" alt="">
                                    </div>
                                </li>
                                <li>
                                    <div class="about-style1-img-box__single">
                                        <img src="assets/images/RASO/IMG-14.jpg" alt="">
                                    </div>
                                </li>
                            </ul>
                            <div class="certified-box-style1">
                                <div class="icon">
                                    <span class="icon-construction"></span>
                                </div>
                                <div class="title">
                                    <h6>certified service</h6>
                                    <h2>Approved Roof<br> Repairing</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-8">
                        <div class="about-style1__content-box">
                            <div class="sec-title">
                                <div class="sub-title">
                                    <div class="border-left"></div>
                                    <h5>Welcome to Raso Waterproofing Company</h5>
                                </div>
                                <h2>Committed to Give Quality Roof Repairing</h2>
                            </div>
                            <div class="about-style1__content-box__inner">
                                <div class="solution-box">
                                    <ul>
                                        <li>
                                            <div class="single-solution-box">
                                                <div class="icon">
                                                    <span class="icon-house"></span>
                                                </div>
                                                <div class="inner-title">
                                                    <h3>Solution for<br> Residential Roofing</h3>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="single-solution-box">
                                                <div class="icon">
                                                    <span class="icon-building"></span>
                                                </div>
                                                <div class="inner-title">
                                                    <h3>Solution for<br> Commercial Roofing</h3>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="inner-text">
                                    <h3>Raso Waterproofing Company is a Delhi NCR based company undertaking waterproofing works all over India, we are known for executing challenging jobs with even tight Schedules.</h3>
                                    <p>The Company is established since2008 earlier in partnership with ‘Noida Waterproofing Company’ so that makes us a pioneers with 13 years of total experience in the sector of waterproofing. Proved ourselves to be one the leading organizations in the field of waterproof treatment work. Ours is a professionally managed organization backed up by highly qualified and skilled Expertise of the trade.</p>
                                    <p>We are proud to proclaim that by virtue of our outstanding workmanship and services, we have been retained as Water Proofing experts by many of the Govt./Semi Govt. and Private organizations. Our area of activity is spread from Manufacturing Industries, IT companies, Residential Apartments to many prestigious projects in the country. </p>
                                </div>
                                <div class="about-style2-manager-box">
                                    <div class="left">
                                        <div class="img-box">
                                            <img src="assets/images/about/user.jpg" alt="">
                                        </div>
                                        <div class="title-box">
                                            <h3>Deepak Raso</h3>
                                            <span>Founder</span>
                                        </div>
                                    </div>
                                    <!-- <div class="right">
                                        <div class="manager-signature-1">
                                            <img src="assets/images/about/manager-signature-1.png" alt="">
                                        </div>
                                    </div> -->
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End About Style1 Area-->

        <!--Start Service Style1 Area-->
        <section class="service-style1-area">
            <div class="service-style1-area-image wow slideInRight" data-wow-delay="100ms" data-wow-duration="2500ms">
                <img src="assets/images/shapes/house-1.jpg" alt="">
            </div>
            <div class="container" id="services">

                <div class="row">
                    <div class="col-xl-12">
                        <div class="service-style1-title">
                            <div class="sec-title">
                                <div class="sub-title">
                                    <div class="border-left"></div>
                                    <h5>our services</h5>
                                </div>
                                <h2>What We Do</h2>
                                <div class="text">
                                    <h4 class="text-white">Providing Full Range of High Quality Waterproofing Services</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-12">
                        <div class="service-style1-tab">
                            <!--Start Service Style1 Tab Button-->
                            <div class="service-style1-tab__button">
                                <ul class="tabs-button-box clearfix">
                                    <li data-tab="#installation" class="tab-btn-item active-btn-item">
                                        <div class="inner">
                                            <span class="icon-broken-house"></span>
                                            <h3>Roof Crack waterproofing</h3>
                                        </div>
                                    </li>
                                    <li data-tab="#cornering" class="tab-btn-item">
                                        <div class="inner">
                                            <span class="icon-joist"></span>
                                            <h3>Chemical water Proofing Coating</h3>
                                        </div>
                                    </li>
                                    <li data-tab="#siding" class="tab-btn-item">
                                        <div class="inner">
                                            <span class="icon-roof1"></span>
                                            <h3>Swimming Pool Waterproofing</h3>
                                        </div>
                                    </li>
                                    <li data-tab="#frame" class="tab-btn-item">
                                        <div class="inner">
                                            <span class="icon-joist-1"></span>
                                            <h3>Commercial Construction</h3>
                                        </div>
                                    </li>
                                    <li data-tab="#layer" class="tab-btn-item">
                                        <div class="inner">
                                            <span class="icon-roof-1"></span>
                                            <h3>Wooden structure roof shed</h3>
                                        </div>
                                    </li>
                                    <li data-tab="#damage" class="tab-btn-item">
                                        <div class="inner">
                                            <span class="icon-construction"></span>
                                            <h3>Terrace waterproofing</h3>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <!--End Service Style1 Tab Button-->

                            <!--Start Tabs Content Box-->
                            <div class="tabs-content-box">

                                <!--Tab-->
                                <div class="tab-content-box-item tab-content-box-item-active" id="installation">
                                    <div class="service-style1-tab-content-box-item">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="service-style1-content-box">
                                                    <div class="text-box">
                                                        <h2>Roof Crack waterproofing</h2>
                                                        <p>Roof crack waterproofing is a crucial process that protects your property from water damage. Roof cracks can occur due to several reasons such as thermal expansion, contraction, age, and weathering. If left unattended, roof cracks can lead to serious water damage to your property. That's why it's essential to provide roof crack waterproofing.</p>
                                                        <div class="bottom-box">
                                                            <h4>Benefits of Roof Crack Waterproofing</h4>
                                                            <ul>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Protection against water damage.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Prolongs the lifespan of your roof.</p>
                                                                </li>
                                                            </ul>
                                                            <ul>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Improves energy efficiency.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Prevents mold growth</p>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="btn-box">
                                                            <a href="JAVASCRIPT:VOID(0)">Read More <span
                                                                    class="icon-right-1"></span></a>
                                                        </div>
                                                    </div>
                                                    <div class="img-box">
                                                        <img src="assets/images/RASO/IMG1.jpg" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!--Tab-->
                                <div class="tab-content-box-item" id="cornering">
                                    <div class="service-style1-tab-content-box-item">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="service-style1-content-box">
                                                    <div class="text-box">
                                                        <h2>Chemical water Proofing Coating</h2>
                                                        <p>Chemical water proofing coating is a process that protects buildings from water damage by applying a special coating to the surface. The coating is designed to prevent water from penetrating the surface, which can cause damage to the building's structure and interior. In this article, we'll discuss chemical water proofing coating in detail, its benefits, and how to find the right contractor for the job. We'll also provide some SEO-targeted tips to help you optimize your content.

                                                        </p>
                                                        <h4>Why Chemical Water Proofing Coating is Important?</h4>
                                                        <p>Chemical water proofing coating is essential for several reasons. Firstly, it helps to prevent water from seeping into the building's structure. Water damage can weaken the structure of the building and cause it to deteriorate over time. This can result in costly repairs and potentially hazardous living conditions for occupants.

Secondly, chemical water proofing coating can help to prolong the lifespan of a building. The coating protects the surface from weathering and other environmental factors that can cause it to deteriorate over time.

Finally, chemical water proofing coating can also improve the energy efficiency of a building. When water seeps through the surface, it can cause insulation to become damp, reducing its effectiveness. This can cause occupants to spend more on heating or cooling the building, as they'll need to compensate for the lost insulation.
</p>
                                                        <div class="bottom-box">
                                                            <h4>Benefits of Chemical Water Proofing Coating</h4>
                                                            <ul>
                                                                
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Protection against water damage.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Prolongs the lifespan of a building.</p>
                                                                </li>
                                                            </ul>
                                                            <ul>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Improves energy efficiency.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Easy maintenance.</p>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="btn-box">
                                                            <a href="#">Read More <span
                                                                    class="icon-right-1"></span></a>
                                                        </div>
                                                    </div>
                                                    <div class="img-box">
                                                        <img src="assets/images/RASO/IMG-15.jpg" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!--Tab-->
                                <div class="tab-content-box-item" id="siding">
                                    <div class="service-style1-tab-content-box-item">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="service-style1-content-box">
                                                    <div class="text-box">
                                                        <h2>Swimming Pool Waterproofing</h2>
                                                        
                                                        <p>Swimming pools are a great way to enjoy the summer months and get some exercise. However, they can also be a source of problems if they're not properly waterproofed. A swimming pool that's not waterproof can cause water to leak into the surrounding area, causing damage to your property and potentially harming your health.</p>
                                                        <h4>Why Swimming Pool Waterproofing is Important?</h4>
                                                        <p>Swimming pool waterproofing is important for several reasons. Firstly, it protects the surrounding area from water damage. Water that leaks from a pool can seep into the ground, causing damage to the foundation of your property. This can result in costly repairs and potentially hazardous living conditions for occupants.
                                                            Secondly, waterproofing your pool helps to prevent leaks, which can cause the pool to lose water and require more maintenance. This can result in higher water bills and more frequent cleaning, as well as other problems like algae growth and slippery surfaces.
                                                            Finally, waterproofing your pool can also improve its lifespan. When water seeps through the surface, it can cause the pool to deteriorate over time. This can result in costly repairs and eventually require the replacement of the entire pool.</p>
                                                        <div class="bottom-box">
                                                            <h4>Benefits of Swimming Pool Waterproofing</h4>
                                                            <ul>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Protection against water damage.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Prevents leaks.</p>
                                                                </li>
                                                            </ul>
                                                            <ul>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Improves lifespan.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Provides a safer swimming environment.</p>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="btn-box">
                                                            <a href="#">Read More <span
                                                                    class="icon-right-1"></span></a>
                                                        </div>
                                                    </div>
                                                    <div class="img-box">
                                                        <img src="assets/images/RASO/IMG-16.webp" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!--Tab-->
                                <div class="tab-content-box-item" id="frame">
                                    <div class="service-style1-tab-content-box-item">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="service-style1-content-box">
                                                    <div class="text-box">
                                                        <h2>Commercial Construction</h2>
                                                        <p>Commercial construction involves building or renovating structures intended for commercial use, such as office buildings, retail stores, restaurants, and warehouses. It's a complex process that requires careful planning, design and execution.</p>
                                                        
                                                        <div class="bottom-box">
                                                            <h4>Benefits of Commercial Construction</h4>
                                                            <ul>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Increased functionality.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Improved aesthetics.</p>
                                                                </li>
                                                            </ul>
                                                            <ul>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Increased property value.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Improved energy efficiency.</p>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="btn-box">
                                                            <a href="#">Read More <span
                                                                    class="icon-right-1"></span></a>
                                                        </div>
                                                    </div>
                                                    <div class="img-box">
                                                        <img src="assets/images/services/service-v1-4.jpg" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!--Tab-->
                                <div class="tab-content-box-item" id="layer">
                                    <div class="service-style1-tab-content-box-item">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="service-style1-content-box">
                                                    <div class="text-box">
                                                        <h2>Roof Layer Fixing</h2>
                                                        <p>Terrace waterproofing is an essential service that involves applying a waterproofing layer to protect the terrace from water damage. Terraces are often exposed to rain, sun, and other elements that can cause damage over time. Waterproofing can prevent water from seeping into the terrace, which can lead to structural damage, mold growth, and other issues.</p>
                                                        <div class="bottom-box">
                                                            <ul>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Protection from water damage.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Improved durability.</p>
                                                                </li>
                                                            </ul>
                                                            <ul>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Enhanced aesthetics.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Increased property value.</p>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="btn-box">
                                                            <a href="#">Read More <span
                                                                    class="icon-right-1"></span></a>
                                                        </div>
                                                    </div>
                                                    <div class="img-box">
                                                        <img src="assets/images/services/service-v1-5.jpg" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!--Tab-->
                                <div class="tab-content-box-item" id="damage">
                                    <div class="service-style1-tab-content-box-item">
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="service-style1-content-box">
                                                    <div class="text-box">
                                                        <h2>Terrace waterproofing</h2>
                                                        <p>Terrace waterproofing is an essential service that involves applying a waterproofing layer to protect the terrace from water damage. Terraces are often exposed to rain, sun, and other elements that can cause damage over time. Waterproofing can prevent water from seeping into the terrace, which can lead to structural damage, mold growth, and other issues.</p>
                                                        <div class="bottom-box">
                                                            <h4>Benefits of Terrace Waterproofing</h4>
                                                            <ul>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Protection from water damage.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Improved durability.</p>
                                                                </li>
                                                            </ul>
                                                            <ul>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Enhanced aesthetics.</p>
                                                                </li>
                                                                <li>
                                                                    <span class="icon-right-1"></span>
                                                                    <p>Increased property value.</p>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="btn-box">
                                                            <a href="#">Read More <span
                                                                    class="icon-right-1"></span></a>
                                                        </div>
                                                    </div>
                                                    <div class="img-box">
                                                        <img src="assets/images/RASO/IMG-8.jpg" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                            <!--End Tabs Content Box-->

                        </div>
                    </div>
                </div>

            </div>
        </section>
        <!--End Service Style1 Area-->

        <!--Start Choose Style1 Area-->
        <section class="choose-style1-area">
            <div class="choose-style1-area-img wow slideInLeft" data-wow-delay="100ms" data-wow-duration="2500ms">
                <img class="paroller" src="assets/images/RASO/IMG-16.webp" alt="">
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="choose-style1-content">
                            <div class="sec-title">
                                <div class="sub-title">
                                    <div class="border-left"></div>
                                    <h5>What reason to choose us</h5>
                                </div>
                                <h2>Why Main Reason to Choose Us</h2>
                                <div class="text">
                                    <ul>
                                        <li>We have 13 year experience in waterproofing market.</li>
                                        <li>We use only high-quality materials made by industry experts.</li>
                                        <li>Our company follows the latest trends in equipment and process.<br>Our staff is experts who upgrade their skills from year to year.</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="choose-style1-content__inner">
                                <ul class="clearfix">
                                    <li>
                                        <div class="single-choose-box-style1 wow fadeInLeft" data-wow-delay="500ms"
                                            data-wow-duration="1200ms">
                                            <div class="icon">
                                                <span class="icon-family-insurance"></span>
                                            </div>
                                            <div class="title">
                                                <h3>Family Tradition<br> Business</h3>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="single-choose-box-style1 wow fadeInLeft" data-wow-delay="300ms"
                                            data-wow-duration="1500ms">
                                            <div class="icon">
                                                <span class="icon-worker"></span>
                                            </div>
                                            <div class="title">
                                                <h3>Professional Trained<br> Workers</h3>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="single-choose-box-style1 wow fadeInRight" data-wow-delay="200ms"
                                            data-wow-duration="1500ms">
                                            <div class="icon">
                                                <span class="icon-inspection-1"></span>
                                            </div>
                                            <div class="title">
                                                <h3>We Do Complete<br> Inpection</h3>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="single-choose-box-style1 wow fadeInRight" data-wow-delay="500ms"
                                            data-wow-duration="1200ms">
                                            <div class="icon">
                                                <span class="icon-badge"></span>
                                            </div>
                                            <div class="title">
                                                <h3>Complete Leakage<br> Warranty</h3>
                                            </div>
                                        </div>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Choose Style1 Area-->


        <!--Start Project Style1 Area-->
        <section class="project-style1-area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="project-style1-area__top">
                            <div class="sec-title">
                                <div class="sub-title">
                                    <div class="border-left"></div>
                                    <h5>our work</h5>
                                </div>
                                <h2>Explore Recent Projects</h2>
                            </div>
                            <!-- <div class="btn-box">
                                <a class="btn-one" href="javascript:void(0);">
                                    <span class="txt">
                                        view all projects
                                        <i class="icon-right"></i>
                                    </span>
                                </a>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>

            <div class="auto-container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="owl-carousel owl-theme thm-owl__carousel project-style1-carousel" data-owl-options='{
                            "loop": false,
                            "autoplay": false,
                            "margin": 30,
                            "nav": false,
                            "dots": true,
                            "smartSpeed": 500,
                            "autoplayTimeout": 10000,
                            "navText": ["<span class=\"left icon-right-arrow\"></span>","<span class=\"right icon-right-arrow\"></span>"],
                            "responsive": {
                                    "0": {
                                        "items": 1
                                    },
                                    "768": {
                                        "items": 2
                                    },
                                    "992": {
                                        "items": 3
                                    },
                                    "1200": {
                                        "items": 4
                                    }
                                }
                            }'>


                            <!--Start Single project Item-->
                            <div class="single-project-item">
                                <div class="img-holder">
                                    <img src="assets/images/RASO/IMG-2.jpg" alt="Awesome Image">
                                    <div class="img-holder-img-bg"></div>
                                    <div class="overlay-button">
                                        <a class="lightbox-image" data-fancybox="gallery"
                                            href="assets/images/RASO/IMG-2.jpg">
                                            <i class="icon-zoom"></i>
                                        </a>
                                       
                                    </div>
                                    <div class="overlay-title">
                                        <p>Alfa Project</p>
                                        <h4><a href="javasript:void(0);">Renovation Of Solar Roof</a></h4>
                                    </div>
                                </div>
                            </div>
                            <!--End Single project Item-->
                            <!--Start Single project Item-->
                            <div class="single-project-item">
                                <div class="img-holder">
                                    <img src="assets/images/RASO/IMG1.jpg" alt="Awesome Image">
                                    <div class="img-holder-img-bg"></div>
                                    <div class="overlay-button">
                                        <a class="lightbox-image" data-fancybox="gallery"
                                            href="assets/images/RASO/IMG1.jpg">
                                            <i class="icon-zoom"></i>
                                        </a>
                                    </div>
                                    <div class="overlay-title">
                                        <p>Alfa Project</p>
                                        <h4><a href="javasript:void(0);">Damage Waterproofing</a></h4>
                                    </div>
                                </div>
                            </div>
                            <!--End Single project Item-->
                            <!--Start Single project Item-->
                            <div class="single-project-item">
                                <div class="img-holder">
                                    <img src="assets/images/RASO/IMG-3.jpg" alt="Awesome Image">
                                    <div class="img-holder-img-bg"></div>
                                    <div class="overlay-button">
                                        <a class="lightbox-image" data-fancybox="gallery"
                                            href="assets/images/RASO/IMG-3.jpg">
                                            <i class="icon-zoom"></i>
                                        </a>
                                    </div>
                                    <div class="overlay-title">
                                        <p>Alfa Project</p>
                                        <h4><a href="javasript:void(0);">Renovation Of Wall</a></h4>
                                    </div>
                                </div>
                            </div>
                            <!--End Single project Item-->
                            <!--Start Single project Item-->
                            <div class="single-project-item">
                                <div class="img-holder">
                                    <img src="assets/images/RASO/IMG-4.jpg" alt="Awesome Image">
                                    <div class="img-holder-img-bg"></div>
                                    <div class="overlay-button">
                                        <a class="lightbox-image" data-fancybox="gallery"
                                            href="assets/images/RASO/IMG-4.jpg">
                                            <i class="icon-zoom"></i>
                                        </a>
                                    </div>
                                    <div class="overlay-title">
                                        <p>Alfa Project</p>
                                        <h4><a href="javasript:void(0);">Renovation Of Roof</a></h4>
                                    </div>
                                </div>
                            </div>
                            <!--End Single project Item-->


                            <!--Start Single project Item-->
                            <div class="single-project-item">
                                <div class="img-holder">
                                    <img src="assets/images/RASO/IMG-4.jpg" alt="Awesome Image">
                                    <div class="img-holder-img-bg"></div>
                                    <div class="overlay-button">
                                        <a class="lightbox-image" data-fancybox="gallery"
                                            href="assets/images/RASO/IMG-4.jpg">
                                            <i class="icon-zoom"></i>
                                        </a>
                                        <a href="javasript:void(0);">
                                            <i class="icon-link1"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <!--End Single project Item-->
                            <!--Start Single project Item-->
                            <div class="single-project-item">
                                <div class="img-holder">
                                    <img src="assets/images/RASO/IMG-5.jpg" alt="Awesome Image">
                                    <div class="img-holder-img-bg"></div>
                                    <div class="overlay-button">
                                        <a class="lightbox-image" data-fancybox="gallery"
                                            href="assets/images/RASO/IMG-5.jpg">
                                            <i class="icon-zoom"></i>
                                        </a>
                                    </div>
                                    <div class="overlay-title">
                                        <p>Alfa Project</p>
                                        <h4><a href="javasript:void(0);">Renovation Of Roof</a></h4>
                                    </div>
                                </div>
                            </div>
                            <!--End Single project Item-->
                            <!--Start Single project Item-->
                            <div class="single-project-item">
                                <div class="img-holder">
                                    <img src="assets/images/RASO/IMG-6.jpg" alt="Awesome Image">
                                    <div class="img-holder-img-bg"></div>
                                    <div class="overlay-button">
                                        <a class="lightbox-image" data-fancybox="gallery"
                                            href="assets/images/RASO/IMG-6.jpg">
                                            <i class="icon-zoom"></i>
                                        </a>
                                    </div>
                                    <div class="overlay-title">
                                        <p>Alfa Project</p>
                                        <h4><a href="javasript:void(0);">Renovation Of Roof</a></h4>
                                    </div>
                                </div>
                            </div>
                            <!--End Single project Item-->
                            <!--Start Single project Item-->
                            <div class="single-project-item">
                                <div class="img-holder">
                                    <img src="assets/images/RASO/IMG-7.jpg" alt="Awesome Image">
                                    <div class="img-holder-img-bg"></div>
                                    <div class="overlay-button">
                                        <a class="lightbox-image" data-fancybox="gallery"
                                            href="assets/images/RASO/IMG-7.jpg">
                                            <i class="icon-zoom"></i>
                                        </a>
                                    </div>
                                    <div class="overlay-title">
                                        <p>Alfa Project</p>
                                        <h4><a href="javasript:void(0);">Renovation Of Roof</a></h4>
                                    </div>
                                </div>
                            </div>
                            <!--End Single project Item-->


                            <!--Start Single project Item-->
                            <div class="single-project-item">
                                <div class="img-holder">
                                    <img src="assets/images/RASO/IMG-8.jpg" alt="Awesome Image">
                                    <div class="img-holder-img-bg"></div>
                                    <div class="overlay-button">
                                        <a class="lightbox-image" data-fancybox="gallery"
                                            href="assets/images/RASO/IMG-8.jpg">
                                            <i class="icon-zoom"></i>
                                        </a>
                                    </div>
                                    <div class="overlay-title">
                                        <p>Alfa Project</p>
                                        <h4><a href="javasript:void(0);">Renovation Of Roof</a></h4>
                                    </div>
                                </div>
                            </div>
                            <!--End Single project Item-->
                            <!--Start Single project Item-->
                            <div class="single-project-item">
                                <div class="img-holder">
                                    <img src="assets/images/RASO/IMG-9.jpg" alt="Awesome Image">
                                    <div class="img-holder-img-bg"></div>
                                    <div class="overlay-button">
                                        <a class="lightbox-image" data-fancybox="gallery"
                                            href="assets/images/RASO/IMG-9.jpg">
                                            <i class="icon-zoom"></i>
                                        </a>
                                    </div>
                                    <div class="overlay-title">
                                        <p>Alfa Project</p>
                                        <h4><a href="javasript:void(0);">Renovation Of Roof</a></h4>
                                    </div>
                                </div>
                            </div>
                            <!--End Single project Item-->



                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Project Style1 Area-->

        <!--Start Cta Style1 Area-->
        <section class="cta-style1-area">
            <div class="container">
                <div class="cta-style1-area__inner">
                    <div class="cta-style1-area__inner-content">
                        <h2>Need Any Water Proofing Help ?</h2>
                        <h3>
                            <a href="tel:8851311255">+91 88513 11255</a>
                        </h3>
                    </div>
                    <div class="cta-style1-area__inner-img-bg"
                        style="background-image: url(assets/images/resources/cta-style1-1.jpg);"></div>
                </div>
            </div>
        </section>
        <!--End Cta Style1 Area-->

        <!--Start Testimonial Style1 Area-->
        <section class="testimonials-style1-area">
            <div class="map-layer paroller" style="background-image: url(assets/images/shapes/map-1.png);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-xl-4">
                        <div class="testimonial-style1-title-box">
                            <div class="sec-title">
                                <div class="sub-title">
                                    <div class="border-left"></div>
                                    <h5>Testimonials</h5>
                                </div>
                                <h2>What They’re<br> Talking About<br> Company?</h2>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-8">
                        <div class="testimonial-style1-content-box">
                            <div class="owl-carousel owl-theme thm-owl__carousel testimonial-style1-carousel owl-nav-style-one"
                                data-owl-options='{
                                "loop": true,
                                "autoplay": true,
                                "margin": 30,
                                "nav": true,
                                "dots": false,
                                "smartSpeed": 500,
                                "autoplayTimeout": 10000,
                                "navText": ["<span class=\"left icon-left-arrow\"></span>","<span class=\"right icon-right-arrow\"></span>"],
                                "responsive": {
                                        "0": {
                                            "items": 1
                                        },
                                        "768": {
                                            "items": 2
                                        },
                                        "992": {
                                            "items": 2
                                        },
                                        "1200": {
                                            "items": 2
                                        }
                                    }
                                }'>

                                <!--Start Single testimonials Style1-->
                                <div class="single-testimonials-style1">
                                    <div class="single-testimonials-style1__inner">
                                        <div class="quote-box">
                                            <span class="icon-quotation"></span>
                                        </div>
                                        <div class="text-box">
                                            <p>Normal that has evolved from gene ration X is on the runway heading
                                                towards a
                                                streamlined cloud solution. strategies to ensure proactive domination.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="customer-info">
                                        <div class="img-box">
                                            <img src="assets/images/testimonial/testimonial-v1-1.jpg" alt="">
                                        </div>
                                        <div class="title-box">
                                            <h3>Robert Mick</h3>
                                            <span>Customer</span>
                                        </div>
                                    </div>
                                </div>
                                <!--End Single testimonials Style1-->

                                <!--Start Single testimonials Style1-->
                                <div class="single-testimonials-style1">
                                    <div class="single-testimonials-style1__inner">
                                        <div class="quote-box">
                                            <span class="icon-quotation"></span>
                                        </div>
                                        <div class="text-box">
                                            <p>Normal that has evolved from gene ration X is on the runway heading
                                                towards a
                                                streamlined cloud solution. strategies to ensure proactive domination.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="customer-info">
                                        <div class="img-box">
                                            <img src="assets/images/testimonial/testimonial-v1-2.jpg" alt="">
                                        </div>
                                        <div class="title-box">
                                            <h3>Marray Joe</h3>
                                            <span>Customer</span>
                                        </div>
                                    </div>
                                </div>
                                <!--End Single testimonials Style1-->

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!--End Testimonial Style1 Area-->


        <!--Start Fact Counter Area-->
        <section class="fact-counter-area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="fact-counter_box">
                            <div class="border-top-color"></div>
                            <ul class="clearfix">

                                <!--Start Single Fact Counter-->
                                <li class="single-fact-counter">
                                    <div class="icon">
                                        <span class="icon-roof"></span>
                                    </div>
                                    <div class="outer-box">
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="50">0</span>
                                        </div>
                                        <div class="title">
                                            <h6>Project Completed</h6>
                                        </div>
                                    </div>
                                </li>
                                <!--End Single Fact Counter-->

                                <!--Start Single Fact Counter-->
                                <li class="single-fact-counter">
                                    <div class="icon">
                                        <span class="icon-worker-1"></span>
                                    </div>
                                    <div class="outer-box">
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="30">0</span>
                                            <i class="icon-plus"></i>
                                        </div>
                                        <div class="title">
                                            <h6>Team Members</h6>
                                        </div>
                                    </div>
                                </li>
                                <!--End Single Fact Counter-->

                                <!--Start Single Fact Counter-->
                                <li class="single-fact-counter">
                                    <div class="icon">
                                        <span class="icon-rating"></span>
                                    </div>
                                    <div class="outer-box">
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="20">0</span>
                                            <i class="icon-plus"></i>
                                        </div>
                                        <div class="title">
                                            <h6>Satisfied Clients</h6>
                                        </div>
                                    </div>
                                </li>
                                <!--End Single Fact Counter-->

                                <!--Start Single Fact Counter-->
                                <li class="single-fact-counter">
                                    <div class="icon">
                                        <span class="icon-skyscrapers1"></span>
                                    </div>
                                    <div class="outer-box">
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="17">0</span>
                                        </div>
                                        <div class="title">
                                            <h6>Total Branches</h6>
                                        </div>
                                    </div>
                                </li>
                                <!--End Single Fact Counter-->

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End Fact Counter Area-->


        <!--Start slogan area-->
        <section class="slogan-area">
            <div class="slogan-area-bg" style="background-image: url(assets/images/backgrounds/slogan-area-bg.jpg);">
            </div>
            <div class="container">
                <div class="slogan-content-box">
                    <div class="inner-title">
                        <h2>Share Our Work. Inspire Others.</h2>
                        <h3>Join our movement to make the world a better<br>
                            place for live with safety.</h3>
                    </div>
                    <div class="btns-box">
                        <div class="left-btn">
                            <a class="btn-one" href="contact.php">
                                <span class="txt">
                                    contact us
                                </span>
                            </a>
                        </div>
                        <div class="video-gallery-style1">
                            <div class="icon wow zoomIn animated" data-wow-delay="300ms" data-wow-duration="1500ms">
                                <a class="video-popup" title="Video Gallery"
                                    href="#">
                                    <span class="icon-play-button"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--End slogan area-->

    <!--Start footer area -->
<footer class="footer-area">
    <div class="footer-area-img-box" data-aos="slide-up" data-aos-easing="linear" data-aos-duration="2500">
        <img class="float-bob-y" src="assets/images/footer/footer-area-img-1.png" alt="">
    </div>
    <!--Start Footer Top-->
    <div class="footer-top">
        <div class="container">
            <div class="footer-top__inner">
                <ul class="footer-contact-info-box1">
                    <li>
                        <div class="footer-contact-info-box1__single">
                            <div class="icon">
                                <span class="icon-location"></span>
                            </div>
                            <div class="text">
                                <p> I-86, near kavita palace, Azad Vihar, Khora Colony, Sector 62A, <br> Noida, Uttar Pradesh 201309</p>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="footer-contact-info-box1__single">
                            <div class="icon">
                                <span class="icon-envelope"></span>
                            </div>
                            <div class="text">
                                <p>Email us:</p>
                                <h5><a href="mailto:Rasowaterproofing@gmail.com">Rasowaterproofing@gmail.com</a></h5>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="footer-contact-info-box1__single">
                            <div class="icon">
                                <span class="icon-telephone"></span>
                            </div>
                            <div class="text">
                                <p>Call us on:</p>
                                <h5><a href="tel:+918851311255">+91 88513 11255</a></h5>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!--End Footer Top-->

    <!--Start Footer Top-->
    <div class="footer-main">
        <div class="container">
            <div class="row">
                <!--Start single footer widget-->
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 single-widget">
                    <div class="single-footer-widget">
                        <div class="our-company-info">
                            <div class="footer-logo-style1">
                                <a href="index.php">
                                    <img src="assets/images/raaso-logo.jpg" alt="Awesome Logo"
                                        title="">
                                </a>
                            </div>
                            <div class="text">
                                <p>Raso Waterproofing Company is a Delhi NCR based company undertaking waterproofing works all over India, we are known for executing challenging jobs with even tight Schedules. </p>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End single footer widget-->

                <!--Start single footer widget-->
                <div class="col-xl-2 col-lg-6 col-md-6 col-sm-12 single-widget">
                    <div class="single-footer-widget single-footer-widget--link-box margin-leftminus1">
                        <div class="title">
                            <h3>Useful Links</h3>
                        </div>
                        <div class="footer-widget-links">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="#">About Us</a></li>
                                <li><a href="contact.php">Appointment</a></li>
                                <li><a href="#">Testimonials</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--End single footer widget-->

                <!--Start single footer widget-->
                <div class="col-xl-2 col-lg-6 col-md-6 col-sm-12 single-widget">
                    <div class="single-footer-widget single-footer-widget--link-box margin-leftminus2">
                        <div class="title">
                            <h3>Our Services</h3>
                        </div>
                        <div class="footer-widget-links">
                            <ul>
                                <li><a href="#">Roof Repairing</a></li>
                                <li><a href="#">Roof Installation</a></li>
                                <li><a href="#">Siding Corner</a></li>
                                <li><a href="#">Damage Roof Repairs</a></li>
                                <li><a href="#">Roof Layers</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--End single footer widget-->

                <!--Start single footer widget-->
                <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 single-widget">
                    <div class="single-footer-widget">
                        <div class="title">
                            <h3>Newsletter</h3>
                        </div>
                        <div class="footer-widget-newsletter-box">
                            <p>Get latest updates and offers.</p>
                            <form action="#" method="post">
                                <div class="form-group">
                                    <input type="email" name="email" placeholder="Enter your email address"
                                        required="">
                                    <button class="submit">
                                        <i class="icon-send"></i>
                                    </button>
                                </div>
                            </form>

                            <div class="footer-social-link">
                                <ul class="clearfix">
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-youtube"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/rasowaterproofing/?igshid=YmMyMTA2M2Y%3D">
                                            <i class="fab fa-instagram"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.facebook.com/people/RASO-Waterproofing/100075980678693/?mibextid=ZbWKwL">
                                            <i class="fab fa-facebook-f"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                </div>
                <!--End single footer widget-->

            </div>
        </div>
    </div>
    <!--End Footer Top-->

    <div class="footer-bottom">
        <div class="container">
            <div class="bottom-inner">
                <div class="copyright-text">
                    <p>
                        &copy; Copyright <a href="index.html">Raso Water Proofing</a> 2022. All right reserved.<br>
                    </p>
                </div>
                <div class="footer-bottom-right">
                    <!-- <p>Created by <a href="#">DesignArc</a></p> -->
                </div>
            </div>
        </div>
    </div>

</footer>
<!--End footer area-->



</div>
<!-- /.page-wrapper -->


<div class="mobile-nav__wrapper">
<div class="mobile-nav__overlay mobile-nav__toggler"></div>
<div class="mobile-nav__content">
    <span class="mobile-nav__close mobile-nav__toggler">
        <i class="icon-x"></i>
    </span>
    <div class="logo-box">
        <a href="index.html" aria-label="logo image">
            <img src="assets/images/resources/mobile-nav-logo.png" alt="" />
        </a>
    </div>
    <div class="mobile-nav-search-box">
        <form class="search-form" action="#">
            <input placeholder="Keyword" type="text">
            <button type="submit">
                <i class="icon-search-interface-symbol"></i>
            </button>
        </form>
    </div>
    <div class="mobile-nav__container"></div>
    <ul class="mobile-nav__contact list-unstyled">
        <li>
            <i class="fa fa-envelope"></i>
            <a href="mailto:info@example.com">info@example.com</a>
        </li>
        <li>
            <i class="fa fa-phone-alt"></i>
            <a href="tel:123456789">444 000 777 66</a>
        </li>
    </ul>
    <div class="mobile-nav__social">
        <a href="#" class="fab fa-twitter"></a>
        <a href="#" class="fab fa-facebook-square"></a>
        <a href="#" class="fab fa-pinterest-p"></a>
        <a href="#" class="fab fa-instagram"></a>
    </div>
</div>
</div>


<div class="search-popup">
    <div class="search-popup__overlay search-toggler"></div>
        <div class="search-popup__content">
            <form action="#">
                <label for="search" class="sr-only">search here</label>
                <input type="text" id="search" placeholder="Search Here..." />
                <button type="submit" aria-label="search submit" class="thm-btn">
                    <i class="icon-search-interface-symbol"></i>
                </button>
            </form>
        </div>
    </div>



<!--Scroll to top-->
<div class="scroll-to-top">
<div>
    <div class="scroll-top-inner">
        <div class="scroll-bar">
            <div class="bar-inner"></div>
        </div>
        <div class="scroll-bar-text">Go To Top</div>
    </div>
</div>
</div>
<!-- Scroll to top end -->


<script src="assets/vendors/jquery/jquery-3.6.0.min.js"></script>
<script src="assets/vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendors/bxslider/jquery.bxslider.min.js"></script>
<script src="assets/vendors/circleType/jquery.circleType.js"></script>
<script src="assets/vendors/circleType/jquery.lettering.min.js"></script>
<script src="assets/vendors/isotope/isotope.js"></script>
<script src="assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js"></script>
<script src="assets/vendors/jquery-appear/jquery.appear.min.js"></script>
<script src="assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="assets/vendors/jquery-migrate/jquery-migrate.min.js"></script>
<script src="assets/vendors/jquery-ui/jquery-ui.js"></script>
<script src="assets/vendors/jquery-validate/jquery.validate.min.js"></script>
<script src="assets/vendors/nice-select/jquery.nice-select.min.js"></script>
<script src="assets/vendors/odometer/odometer.min.js"></script>
<script src="assets/vendors/owl-carousel/owl.carousel.min.js"></script>
<script src="assets/vendors/swiper/swiper.min.js"></script>
<script src="assets/vendors/vegas/vegas.min.js"></script>
<script src="assets/vendors/wnumb/wNumb.min.js"></script>
<script src="assets/vendors/wow/wow.js"></script>
<script src="assets/vendors/extra-scripts/jquery.paroller.min.js"></script>
<script src="assets/vendors/language-switcher/jquery.polyglot.language.switcher.js"></script>
<script src="assets/vendors/extra-scripts/jquery-sidebar-content.js"></script>
<script src="assets/vendors/fancybox/jquery.fancybox.js"></script>
<script src="assets/vendors/aos/aos.js"></script>
<script src="assets/vendors/extra-scripts/jarallax.min.js"></script>
<script src="assets/vendors/extra-scripts/TweenMax.min.js"></script>


<!-- Template js -->
<script src="assets/js/custom.js"></script>
<script>
   $("form#enquiry_form").submit(function(e) {
      $(':button[type="submit"]').prop('disabled', true);
    e.preventDefault();    
    var formData = new FormData(this);
    $.ajax({
    url: $(this).attr('action'),
    type: 'POST',
    data: formData,
    cache: false,
    contentType: false,
    processData: false,
    dataType: 'json',
    success: function (data) {
        if(data.status==200) {
        //$('.modal').modal('hide');
        toastr.success(data.message);
        setTimeout(function(){
        location.reload();
        },1000)
        }else if(data.status==403) {
        toastr.error(data.message);
        $(':input[type="submit"]').prop('disabled', false);
        }else{
        toastr.error('Something went wrong');
        $(':input[type="submit"]').prop('disabled', false);
        }
    },
    error: function(){} 
    });
});
</script>

</body>
</html>